package stepDefinations;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class NykaaSteps {
	
	WebDriver driver;

    @Given("User is on Nykaa homepage")
    public void user_is_on_nykaa_homepage() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.nykaa.com");

        
        try {
            WebElement closeButton = driver.findElement(By.xpath("//button[contains(text(),'✕')]"));
            closeButton.click();
        } catch (NoSuchElementException ignored) {}
    }
    

    @When("User selects a product and adds it to the cart")
    public void user_selects_a_product_and_adds_it_to_the_cart() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        WebElement productCat = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[text()='Health & Wellness']")));
        productCat.click();

        for (String handle : driver.getWindowHandles()) {
            driver.switchTo().window(handle);
        }
        WebElement product = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[text()='Skin Supplements']")));
        product.click();
        

        WebElement addToBag = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(text(),'Add to Bag')]")));
        addToBag.click();
        
        WebElement cartIcon = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[@title='Cart']")));
        cartIcon.click();
    }

    @And("Proceeds to checkout")
    public void proceeds_to_checkout() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        WebElement proceedButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[contains(text(),'Proceed')]")));
        proceedButton.click();
    }

    @Then("User reaches the second authentication payment screen")
    public void user_reaches_the_second_authentication_payment_screen() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//h2[contains(text(),'Payment Options')]")));

        System.out.println("User has reached the second authentication payment screen.");
        
        driver.quit();
    }    

}
